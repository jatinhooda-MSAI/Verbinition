"""NLA adaptation helpers."""

